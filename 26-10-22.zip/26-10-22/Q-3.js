// JavaScript source code
function myFunction() {

    document.getElementById('demo').innerHTML= 'This is the 2nd Paragraph';
   
}