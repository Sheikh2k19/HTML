// JavaScript source code
function Alertmessage(){
    alert("Error");

}