// JavaScript source code

function myFunction()
{
    document.getElementById("Block").style.display='none';
    
}
