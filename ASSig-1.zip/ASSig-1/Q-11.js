// JavaScript source code
function CalculateTaxDetails() {
   
    var salary = parseInt(document.getElementById("Msalary").value);
    var anumSalary = salary * 12;

    if (anumSalary < 600000)
    {
        alert("dddd");
        document.getElementById("demo").innerHTML = '0 tax';
    }
    if (anumSalary > 600000 && anumSalary < 1200000) {
        alert("hdhf");
        var exceedAmount = anumSalary - 600000;
        var Onepercet = exceedAmount / 100;
        var percentage = Onepercent * 2.5 * 100;
        var remainingSalary = anumSalary - percentage;
        document.getElementById("demo").innerHTML = "Monthly Taxable amount is: Rs " + percentage;
        document.getElementById("demo").innerHTML = "Monthly Salary after TAX is: Rs " + remainingSalary;
        document.getElementById("demo").innerHTML = "Yearly Tax is: Rs " + percentage * 12;
        document.getElementById("demo").innerHTML = "Yearly income after Tax is: Rs " + remainingSalary * 12;
    }
    if (anumSalary > 1200000 && anumSalary < 2400000) {
        alert("fff");
        var exceedAmount = anumSalary - 1200000;
        var Onepercet = exceedAmount / 100;
        var percentage = 15000+Onepercent * 12.5 * 100;
        var remainingSalary = anumSalary - percentage;
        document.getElementById("demo").innerHTML = "Monthly Taxable amount is: Rs " + percentage;
        document.getElementById("demo").innerHTML = "Monthly Salary after TAX is: Rs " + remainingSalary;
        document.getElementById("demo").innerHTML = "Yearly Tax is: Rs " + percentage * 12;
        document.getElementById("demo").innerHTML = "Yearly income after Tax is: Rs " + remainingSalary * 12;
    }
    if (anumSalary > 2400000 && anumSalary < 3600000) {
        alert("ggg");
        var exceedAmount = anumSalary - 2400000;
        var Onepercet = exceedAmount / 100;
        var percentage = 165000 + Onepercent * 20 * 100;
        var remainingSalary = anumSalary - percentage;
        document.getElementById("demo").innerHTML = "Monthly Taxable amount is: Rs " + percentage;
        document.getElementById("demo").innerHTML = "Monthly Salary after TAX is: Rs " + remainingSalary;
        document.getElementById("demo").innerHTML = "Yearly Tax is: Rs " + percentage * 12;
        document.getElementById("demo").innerHTML = "Yearly income after Tax is: Rs " + remainingSalary * 12;
    }
    if (anumSalary > 3600000 && anumSalary < 6000000) {
        alert("hhh");
        var exceedAmount = anumSalary - 3600000;
        var Onepercet = exceedAmount / 100;
        var percentage = 405000 + Onepercent * 25 * 100;
        var remainingSalary = salary - percentage;
        document.getElementById("demo").innerHTML = "Monthly Taxable amount is: Rs " + percentage;
        document.getElementById("demo").innerHTML = "Monthly Salary after TAX is: Rs " + remainingSalary;
        document.getElementById("demo").innerHTML = "Yearly Tax is: Rs " + percentage * 12;
        document.getElementById("demo").innerHTML = "Yearly income after Tax is: Rs " + remainingSalary * 12;
    }
    if (anumSalary > 6000000 && anumSalary < 12000000) {
        alert("iii");
        var exceedAmount = anumSalary - 6000000;
        var Onepercet = exceedAmount / 100;
        var percentage = 1005000 + Onepercent * 32.5 * 100;
        var remainingSalary = anumSalary - percentage;
        document.getElementById("demo").innerHTML = "Monthly Taxable amount is: Rs " + percentage;
        document.getElementById("demo").innerHTML = "Monthly Salary after TAX is: Rs " + remainingSalary;
        document.getElementById("demo").innerHTML = "Yearly Tax is: Rs " + percentage * 12;
        document.getElementById("demo").innerHTML = "Yearly income after Tax is: Rs " + remainingSalary * 12;
    }
    if (salary > 12000000 ) {
        alert("jjj");
        var exceedAmount = salary - 12000000;
        var Onepercet = exceedAmount / 100;
        var percentage = 2955000 + Onepercent * 35 * 100;
        var remainingSalary = salary - percentage;
        document.getElementById("demo").innerHTML = "Monthly Taxable amount is: Rs " + percentage;
        document.getElementById("demo").innerHTML = "Monthly Salary after TAX is: Rs " + remainingSalary;
        document.getElementById("demo").innerHTML = "Yearly Tax is: Rs " + percentage * 12;
        document.getElementById("demo").innerHTML = "Yearly income after Tax is: Rs " + remainingSalary * 12;
    }
}
