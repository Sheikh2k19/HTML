// JavaScript source code
function Alertmessage(){
    alert("error");

}