// JavaScript source code


function CalculateCharacters() {
    var EnteredText;
    alert("jjss");
    EnteredText = document.getElementById("text").value;
    let length = EnteredText.length;
    document.getElementById("demo").innerText = length;
}
