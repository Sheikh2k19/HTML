// JavaScript source code
function CalculateTaxDetails() {
   
    var salary = parseInt(document.getElementById("Msalary").value);
    if (salary < 600000)
    {
        alert("dddd");
        document.getElementById("demo").innerHTML = '0 tax';
    }
    if (salary > 600000 && salary < 1200000) {
        alert("hdhf");
        var exceedAmount = salary - 600000;
        var Onepercet = exceedAmount / 100;
        var percentage = Onepercent * 2.5 * 100;
        var remainingSalary = salary - percentage;
        document.getElementById("demo").innerHTML = "Monthly Taxable amount is: Rs " + percentage;
        document.getElementById("demo").innerHTML = "Monthly Salary after TAX is: Rs " + remainingSalary;
        document.getElementById("demo").innerHTML = "Yearly Tax is: Rs " + percentage * 12;
        document.getElementById("demo").innerHTML = "Yearly income after Tax is: Rs " + remainingSalary * 12;
    }
    if (salary > 1200000 && salary < 2400000) {
        alert("fff");
        var exceedAmount = salary - 1200000;
        var Onepercet = exceedAmount / 100;
        var percentage = 15000+Onepercent * 12.5 * 100;
        var remainingSalary = salary - percentage;
        document.getElementById("demo").innerHTML = "Monthly Taxable amount is: Rs " + percentage;
        document.getElementById("demo").innerHTML = "Monthly Salary after TAX is: Rs " + remainingSalary;
        document.getElementById("demo").innerHTML = "Yearly Tax is: Rs " + percentage * 12;
        document.getElementById("demo").innerHTML = "Yearly income after Tax is: Rs " + remainingSalary * 12;
    }
    if (salary > 2400000 && salary < 3600000) {
        alert("ggg");
        var exceedAmount = salary - 2400000;
        var Onepercet = exceedAmount / 100;
        var percentage = 165000 + Onepercent * 20 * 100;
        var remainingSalary = salary - percentage;
        document.getElementById("demo").innerHTML = "Monthly Taxable amount is: Rs " + percentage;
        document.getElementById("demo").innerHTML = "Monthly Salary after TAX is: Rs " + remainingSalary;
        document.getElementById("demo").innerHTML = "Yearly Tax is: Rs " + percentage * 12;
        document.getElementById("demo").innerHTML = "Yearly income after Tax is: Rs " + remainingSalary * 12;
    }
    if (salary > 3600000 && salary < 6000000) {
        alert("hhh");
        var exceedAmount = salary - 3600000;
        var Onepercet = exceedAmount / 100;
        var percentage = 405000 + Onepercent * 25 * 100;
        var remainingSalary = salary - percentage;
        document.getElementById("demo").innerHTML = "Monthly Taxable amount is: Rs " + percentage;
        document.getElementById("demo").innerHTML = "Monthly Salary after TAX is: Rs " + remainingSalary;
        document.getElementById("demo").innerHTML = "Yearly Tax is: Rs " + percentage * 12;
        document.getElementById("demo").innerHTML = "Yearly income after Tax is: Rs " + remainingSalary * 12;
    }
    if (salary > 6000000 && salary < 12000000) {
        alert("iii");
        var exceedAmount = salary - 6000000;
        var Onepercet = exceedAmount / 100;
        var percentage = 1005000 + Onepercent * 32.5 * 100;
        var remainingSalary = salary - percentage;
        document.getElementById("demo").innerHTML = "Monthly Taxable amount is: Rs " + percentage;
        document.getElementById("demo").innerHTML = "Monthly Salary after TAX is: Rs " + remainingSalary;
        document.getElementById("demo").innerHTML = "Yearly Tax is: Rs " + percentage * 12;
        document.getElementById("demo").innerHTML = "Yearly income after Tax is: Rs " + remainingSalary * 12;
    }
    if (salary > 12000000 ) {
        alert("jjj");
        var exceedAmount = salary - 12000000;
        var Onepercet = exceedAmount / 100;
        var percentage = 2955000 + Onepercent * 35 * 100;
        var remainingSalary = salary - percentage;
        document.getElementById("demo").innerHTML = "Monthly Taxable amount is: Rs " + percentage;
        document.getElementById("demo").innerHTML = "Monthly Salary after TAX is: Rs " + remainingSalary;
        document.getElementById("demo").innerHTML = "Yearly Tax is: Rs " + percentage * 12;
        document.getElementById("demo").innerHTML = "Yearly income after Tax is: Rs " + remainingSalary * 12;
    }
}
