﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Threading.Tasks;
using Microsoft.AspNetCore.Mvc;
using Microsoft.Extensions.Logging;

namespace WebApplication1.Controllers
{
    [ApiController]
    [Route("[controller]")]
    public class BookStoreController : ControllerBase
    {
        //Task-1
        List<BookStore> BookList = new List<BookStore>
        {
            new BookStore {category="Math", name="Book1", shelfNumber=1, price=200},
            new BookStore {category="Math", name="Book2", shelfNumber=1, price=400},
            new BookStore {category="Math", name="Book3", shelfNumber=1, price=300},
            new BookStore {category="Math", name="Book4", shelfNumber=1, price=200},
            new BookStore {category="Math", name="Book5", shelfNumber=1, price=500},
            //
            new BookStore {category="English", name="Book6", shelfNumber=2, price=300},
            new BookStore {category="English", name="Book7", shelfNumber=2, price=500},
            new BookStore {category="English", name="Book8", shelfNumber=2, price=600},
            new BookStore {category="English", name="Book9", shelfNumber=2, price=300},
            new BookStore {category="English", name="Book10", shelfNumber=2, price=700},
            //
            new BookStore {category="Programming", name="Book11", shelfNumber=3, price=300},
            new BookStore {category="Programming", name="Book12", shelfNumber=3, price=400},
            new BookStore {category="Programming", name="Book13", shelfNumber=3, price=400},
            new BookStore {category="programming", name="Book14", shelfNumber=3, price=400},
            new BookStore {category="Programming", name="Book15", shelfNumber=3, price=400},
            //
            new BookStore {category="Electronics", name="Book16", shelfNumber=4, price=300},
            new BookStore {category="Electronics", name="Book17", shelfNumber=4, price=300},
            new BookStore {category="Electronics", name="Book18", shelfNumber=4, price=300},
            new BookStore {category="Electronics", name="Book19", shelfNumber=4, price=300},
            new BookStore {category="Electronics", name="Book20", shelfNumber=4, price=300},
        };
        //task-2
        List<User> UserData = new List<User>
        {
            new User {ID= 1, Name="Asif" , BookIssued=new List<string> {"Book1"} },
            new User {ID= 2, Name="Aslam" , BookIssued=new List<string> {"Book3"} },
            new User {ID= 3, Name="Amjad" , BookIssued=new List<string> {"Book5","Book6"} },
            new User {ID= 4, Name="Aqib" , BookIssued= new List<string>{"Book7"} },
            new User {ID= 5, Name="Nasir" , BookIssued=new List<string> {"Book9","Book10"} },
            new User {ID= 6, Name="Kashif" , BookIssued=new List<string> {"Book12"} },
            new User {ID= 7, Name="Ahmad" , BookIssued=new List<string> {"Book13"} },
            new User {ID= 8, Name="Akbar" , BookIssued=new List<string> {"Book16"} },
            new User {ID= 9, Name="Ali" , BookIssued=new List<string> {"Book17","Book18"} },
           new User {ID= 10, Name="Usman" , BookIssued=new List<string> {"Book19" }},
        };

        private readonly ILogger<BookStoreController> _logger;
        public BookStoreController(ILogger<BookStoreController> logger)
        {
            _logger = logger;
        }
        //Task-3-check
        [Route("names")]
        [HttpGet]
        public List<BookStore> Get()
        {


            return BookList;
        }
        //Task-3
        [Route("booknames")]
        [HttpGet]
        public List<string> GetBooknames()
        {
            var Booknames = from book in BookList
                            select book.name;

            return Booknames.ToList();
        }
        //Task-5
        [Route("findbook/{name}")]
        [HttpGet]
        public BookStore GetBookDetails(string name)
        {
            var Bookdetail = from book in BookList
                            where book.name == name
                            select book;

            return Bookdetail.FirstOrDefault();
        }
        //Task-6
        [Route("finduser/{name}")]
        [HttpGet]
        public User GetUserDetails(string name)
        {
            var Userdetail = from user in UserData
                             where user.Name == name
                             select user;
           
            return Userdetail.FirstOrDefault();
        }
        //task-7
        [Route("AddBook")]
        [HttpPost]
        public List<BookStore> AddBook([FromBody] BookStore BookInput)
        {
            BookList.Add(BookInput);
            return BookList;
        }
        
        //task-8,Task-4
        [Route("AddUser")]
        [HttpPost]
        public List<User> AddUser([FromBody] User userInput)
        {
            UserData.Add(userInput);
            return UserData;
        }
        //Task-9
        [Route("updateBook/{index}")]
        [HttpPut]
        public List<BookStore> UpdateBooklist(int weatherUpdateIndex, [FromBody]BookStore weatherUpdateInput)
        {
            
            BookList[weatherUpdateIndex - 1].category= weatherUpdateInput.category;
            BookList[weatherUpdateIndex - 1].name = weatherUpdateInput.name;
            BookList[weatherUpdateIndex - 1].shelfNumber = weatherUpdateInput.shelfNumber;
            BookList[weatherUpdateIndex - 1].price = weatherUpdateInput.price;
            return BookList;
        }
        //Task-10
        [Route("updateUser/{index}")]
        [HttpPut]
        public List<User> UpdateUserList(int weatherUpdateIndex, [FromBody]User weatherUpdateInput)
        {

            UserData[weatherUpdateIndex - 1].ID = weatherUpdateInput.ID;
            UserData[weatherUpdateIndex - 1].Name = weatherUpdateInput.Name;
            return UserData;
        }
        //Task-11
        [Route("issueBook/{id}/{bookname}")]
        [HttpPost]
        public string IssueBooks(string bookname, int id)
        {
            foreach(User user in UserData)
            {
             if(user.BookIssued.Contains(bookname))
                {
                    return "This Book is alreadu Issued";
                }

            }
            var Userdetail = from user in UserData
                             where user.ID == id
                             select user;
            Userdetail.FirstOrDefault().BookIssued.Add(bookname);

            return "Book Is issued";
            
        }


    }
}
