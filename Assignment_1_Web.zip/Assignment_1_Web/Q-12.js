function NameFormating() {
    var firstName, LastName;
    UserName = document.getElementById("fname").value;
    Password = document.getElementById("lname").value;

    if (UserName === "user" && Password === "web_dev") {
        alert("You have successfully logged in.");
        location.replace("file:///C:/Users/4399/Desktop/26-10-22/Q-6.html");
    } else {
        alert("Invalid Password or User Name");
    }
}
// JavaScript source code
