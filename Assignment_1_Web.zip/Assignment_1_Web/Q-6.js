// JavaScript source code
function NameFormating() {
    location.replace("file:///C:/Users/4399/Desktop/26-10-22/Q-6.html");
}