// JavaScript source code


function CalculateCharacters() {
    var EnteredText;
    var num=0;
    EnteredText = document.getElementById("text").value;
    let length = EnteredText.length;
    for (let i = 0; i < EnteredText.length; i++)
    {
        if (EnteredText[i] == " ")
        {
            num++;
        }
    }
    var actuallength = length - num;
    document.getElementById("demo").innerText = actuallength;
}
