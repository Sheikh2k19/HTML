// JavaScript source code
//Function to give alert message on the click of button
function Alertmessage(){
    alert("Error");

}