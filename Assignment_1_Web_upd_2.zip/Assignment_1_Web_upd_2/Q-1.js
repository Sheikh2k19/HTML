// JavaScript source code
//Function to hide the text on the click of button.
function myFunction()
{
    document.getElementById("Block").style.display='none';
    
}
