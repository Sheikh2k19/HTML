// JavaScript source code
/*Function to Calculate Tax */
function CalculateTaxDetails() {
   
    var salary = parseInt(document.getElementById("Msalary").value);
    var yearlySalary = salary * 12;
    if (yearlySalary <= 600000)
    {
        alert("dddd");
        document.getElementById("demo").innerHTML = 0;
        document.getElementById("demo1").innerHTML = salary;
        document.getElementById("demo2").innerHTML = 0;
        document.getElementById("demo3").innerHTML = yearlySalary;
    }
    else if (yearlySalary > 600000 && yearlySalary < 1200000) {
        alert("djdj");
        var exceedAmount = yearlySalary - 600000;
        var percentage =exceedAmount * 0.025;
        var remainingSalary = yearlySalary - percentage;
        alert("hdhf");
        document.getElementById("demo").innerHTML = (percentage/12) ;
        document.getElementById("demo1").innerHTML = (remainingSalary/12);
        document.getElementById("demo2").innerHTML = percentage  ;
        document.getElementById("demo3").innerHTML =remainingSalary;
       
    }
    else if (yearlySalary > 1200000 && yearlySalary < 2400000) {
        alert("fff");
        var exceedAmount = yearlySalary - 1200000;
        var percentage = 15000 + (exceedAmount*0.125);
        var remainingSalary = yearlySalary - percentage;
        document.getElementById("demo").innerHTML = (percentage / 12);
        document.getElementById("demo1").innerHTML = (remainingSalary / 12);
        document.getElementById("demo2").innerHTML = percentage;
        document.getElementById("demo3").innerHTML = remainingSalary;
    }
    else if (yearlySalary > 2400000 && yearlySalary < 3600000) {
        alert("ggg");
        var exceedAmount = yearlySalary - 2400000;
        var percentage = 165000 + (exceedAmount * 0.200);
        var remainingSalary = yearlySalary - percentage;
        document.getElementById("demo").innerHTML = (percentage / 12);
        document.getElementById("demo1").innerHTML = (remainingSalary / 12);
        document.getElementById("demo2").innerHTML = percentage;
        document.getElementById("demo3").innerHTML = remainingSalary;
    }
    else if (yearlySalary > 3600000 && yearlySalary < 6000000) {
        alert("hhh");
        var exceedAmount = yearlySalary - 3600000;
        var percentage = 405000 + (exceedAmount * 0.250);
        var remainingSalary = yearlySalary - percentage;
        document.getElementById("demo").innerHTML = (percentage / 12);
        document.getElementById("demo1").innerHTML = (remainingSalary / 12);
        document.getElementById("demo2").innerHTML = percentage;
        document.getElementById("demo3").innerHTML = remainingSalary;
    }
    else if (yearlySalary > 6000000 && yearlySalary < 12000000) {
        alert("iii");
        var exceedAmount = yearlySalary - 6000000;
        var percentage = 1005000 + (exceedAmount * 0.325);
        var remainingSalary = yearlySalary - percentage;
        document.getElementById("demo").innerHTML = (percentage / 12);
        document.getElementById("demo1").innerHTML = (remainingSalary / 12);
        document.getElementById("demo2").innerHTML = percentage;
        document.getElementById("demo3").innerHTML = remainingSalary;
    }
    else if (yearlySalary > 12000000) {
        alert("jjj");
        var exceedAmount = yearlySalary - 12000000;
        var percentage = 2955000 + (exceedAmount * 0.350);
      
        var remainingSalary = yearlySalary - percentage;
        document.getElementById("demo").innerHTML = (percentage / 12);
        document.getElementById("demo1").innerHTML = (remainingSalary / 12);
        document.getElementById("demo2").innerHTML = percentage;
        document.getElementById("demo3").innerHTML = remainingSalary;
    }
}
