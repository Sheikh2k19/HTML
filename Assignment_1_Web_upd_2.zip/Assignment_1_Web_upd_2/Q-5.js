// JavaScript source code
//Function that show & hide text on the click of button

function myFunction() {
    var x = document.getElementById("Block");
    if (x.style.display === "none") {
        x.style.display = "block";
    } else {
        x.style.display = "none";
    }
}