// JavaScript source code
//Function that links   the click of button
function NameFormating() {
    location.replace("file:///G:/Assignment_1_Web/Q-6.html");
}