// JavaScript source code
/*Function to do complete form details */
function NameFormating() {
    var Name, Email,DOB;
    let count=0;
    let age=0;
    let presentyear=2022;
    Name = document.getElementById("fname").value;
    Email = document.getElementById("lname").value;
    DOB = document.getElementById("birthday").value;
    let getyear = new Date(DOB);
    let year = getyear.getFullYear();
    let namelength = Name.length;
    let emaillength = Email.length;
    let DOBlength = DOB.length;
    document.getElementById("demo").value = age;

        try {

            if (namelength > 10)
            {
                alert("Character limits Execeed");
            }
            else if (namelength == 0)
            {
                alert("Name Cannot be empty");
            }
        }
        catch (err) {
            document.getElementById("demo").innerHTML = err.message;
        }

    try {
        for(let i=0;i<emaillength;i++)
        {
            if(Email[i]=='@')
            {
                count++;
            }
        }
        if (emaillength == 0) {
            alert("Email Cannot be empty");
        }
        else if (count == 2) {
            alert("Invalid Email"); 
        }
    }
    catch (err) {
        document.getElementById("demo").innerHTML = err.message;
    }
    try {
        age = presentyear - year;
        if (DOBlength == 0)
        {
            alert("Date Cannot be empty");
        }
        else if (age < 13) {
            alert("Hello Kid! You are too young for this");
        }  
            }
    catch (err) {
        document.getElementById("demo").innerHTML = err.message;
    }

    }
   
