// JavaScript source code
//Function to change the image  on the click of button
function myFunction() {
    
    document.getElementById('myImage').src='Garment-1.png';
    document.getElementById('myImage').src = 'Garment-2.png';
}