// JavaScript source code
//Function to change the text  on the click of button
function myFunction() {

    document.getElementById('demo').innerHTML= 'This is the 2nd Paragraph';
   
}