// JavaScript source code

var num = 5;
function Add() {
 
     num++;
     document.getElementById("answer").value = num;
}
function Subtract() {
    num--;
    document.getElementById("answer").value = num;
}