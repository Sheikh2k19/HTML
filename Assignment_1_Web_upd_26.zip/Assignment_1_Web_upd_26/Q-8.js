// JavaScript source code
/*Function to do name Formating */
function NameFormating() {
    var firstName, LastName;
    var a = document.getElementById("namesformat").value;
     if(a==1)
     {
         firstName = document.getElementById("fname").value;
         LastName = document.getElementById("lname").value;
         document.getElementById("demo").innerHTML = firstName + LastName;
     }
     else
     {
         firstName = document.getElementById("fname").value;
         LastName = document.getElementById("lname").value;
         document.getElementById("demo").innerHTML = LastName + " "+firstName;
     }
}
